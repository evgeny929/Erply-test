<?php

session_start();

// include ERPLY API class
include("../../include/EAPI.class.php");

// Initialise class
$api = new EAPI();

// Configuration settings
$api->clientCode = 399035;
$api->username = "evgeny929@gmail.com";
$api->password = "29031993Jeka";
$api->url = "https://".$api->clientCode.".erply.com/api/";


// Delete customer group
$inputs = array(
    "searchName" => "Product 6",
);

// Get client groups from API
// No input parameters are needed
$result = $api->sendRequest("getProducts", $inputs);

// Default output format is JSON, so we'll decode it into a PHP array
$output = json_decode($result, true);

print "<pre>";
print_r($output);
print "</pre>";

?>